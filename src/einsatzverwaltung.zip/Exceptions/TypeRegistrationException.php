<?php
namespace abrain\Einsatzverwaltung\Exceptions;

use Exception;

/**
 * Class TypeRegistrationException
 * @package abrain\Einsatzverwaltung\Exceptions
 */
class TypeRegistrationException extends Exception
{

}
