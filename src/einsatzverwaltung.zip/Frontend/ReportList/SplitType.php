<?php

namespace abrain\Einsatzverwaltung\Frontend\ReportList;

/**
 * Class SplitType
 * @package abrain\Einsatzverwaltung\Frontend\ReportList
 */
abstract class SplitType
{
    const NONE = 0;
    const MONTHLY = 1;
    const QUARTERLY = 2;
}
