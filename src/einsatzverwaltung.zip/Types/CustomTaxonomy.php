<?php

namespace abrain\Einsatzverwaltung\Types;

/**
 * Interface CustomTaxonomy
 * @package abrain\Einsatzverwaltung\Types
 */
interface CustomTaxonomy extends CustomType
{

}
