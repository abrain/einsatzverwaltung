<?php
namespace abrain\Einsatzverwaltung\Exceptions;

use Exception;

/**
 * Class ImportException
 * @package abrain\Einsatzverwaltung\Exceptions
 */
class ImportException extends Exception
{

}
