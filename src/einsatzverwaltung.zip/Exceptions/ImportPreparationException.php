<?php
namespace abrain\Einsatzverwaltung\Exceptions;

use Exception;

/**
 * Class ImportPreparationException
 * @package abrain\Einsatzverwaltung\Exceptions
 */
class ImportPreparationException extends Exception
{

}
